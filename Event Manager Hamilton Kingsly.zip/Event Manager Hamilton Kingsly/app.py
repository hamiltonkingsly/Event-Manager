from flask import Flask, request, jsonify
from utils import load_events, save_events, sort_events
import uuid

app = Flask(__name__)
EVENT_FILE = "events.json"

@app.route("/")
def home():
    return jsonify({"message": "Welcome to Event Scheduler System!"}), 200

# Create an event
@app.route("/events", methods=["POST"])
def create_event():
    data = request.get_json()
    required_fields = ["title", "description", "start_time", "end_time"]

    if not all(field in data for field in required_fields):
        return jsonify({"error": "Missing one or more required fields"}), 400

    new_event = {
        "id": str(uuid.uuid4()),
        "title": data["title"],
        "description": data["description"],
        "start_time": data["start_time"],
        "end_time": data["end_time"]
    }

    events = load_events(EVENT_FILE)
    events.append(new_event)
    save_events(EVENT_FILE, events)
    return jsonify({"message": "Event created", "event": new_event}), 201

# Read all events
@app.route("/events", methods=["GET"])
def list_events():
    events = load_events(EVENT_FILE)
    return jsonify(sort_events(events)), 200

# Update an event
@app.route("/events/<event_id>", methods=["PUT"])
def update_event(event_id):
    data = request.get_json()
    events = load_events(EVENT_FILE)
    for event in events:
        if event["id"] == event_id:
            for key in ["title", "description", "start_time", "end_time"]:
                if key in data:
                    event[key] = data[key]
            save_events(EVENT_FILE, events)
            return jsonify({"message": "Event updated", "event": event}), 200
    return jsonify({"error": "Event not found"}), 404

# Delete an event
@app.route("/events/<event_id>", methods=["DELETE"])
def delete_event(event_id):
    events = load_events(EVENT_FILE)
    updated_events = [event for event in events if event["id"] != event_id]
    if len(updated_events) == len(events):
        return jsonify({"error": "Event not found"}), 404
    save_events(EVENT_FILE, updated_events)
    return jsonify({"message": "Event deleted"}), 200

if __name__ == "__main__":
    app.run(debug=True)
