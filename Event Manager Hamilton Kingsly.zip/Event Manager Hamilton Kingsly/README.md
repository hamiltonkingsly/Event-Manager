
# 🗓️ Event Scheduler System (Flask API)

A simple backend Event Scheduler System built with Flask that allows users to **create**, **view**, **update**, and **delete** events, with persistent storage and full Postman API support.

---

## 🚀 Features

- Create events with title, description, start and end time
- View all events sorted by start time
- Update existing events by ID
- Delete events by ID
- Data saved persistently to a JSON file
- Full Postman collection provided
- Pytest test suite included

---

## 📦 Installation

### 1. Clone the repo
```bash
git clone https://github.com/your-username/event-scheduler.git
cd event-scheduler
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

---

## ▶️ Running the App

```bash
python app.py
```

Server will start at: `http://127.0.0.1:5000/`

---

## 📬 API Endpoints

| Method | Endpoint             | Description               |
|--------|----------------------|---------------------------|
| GET    | `/`                  | Welcome message           |
| POST   | `/events`            | Create a new event        |
| GET    | `/events`            | List all events           |
| PUT    | `/events/<event_id>`| Update event by ID        |
| DELETE | `/events/<event_id>`| Delete event by ID        |

---

## 🔁 Example JSON for Event

```json
{
  "title": "Team Meeting",
  "description": "Weekly sync-up",
  "start_time": "2025-06-28T10:00:00",
  "end_time": "2025-06-28T11:00:00"
}
```

---

## 🧪 Running Tests

Make sure Flask app is **not running** while running tests:

```bash
pytest test_app.py
```

---

## 📬 Postman Collection

1. Open Postman → Import
2. Choose file: `EventScheduler_with_PUT.postman_collection.json`
3. Use the 4 included API requests

---

## 📁 Project Structure

```
├── app.py
├── utils.py
├── events.json
├── requirements.txt
├── test_app.py
├── README.md
└── EventScheduler_with_PUT.postman_collection.json
```

---

## 🤝 Contributing

Pull requests are welcome! For major changes, open an issue first to discuss what you would like to change.

---

## 🧑‍💻 Author

**Your Name**  
[LinkedIn](https://linkedin.com/) | [GitHub](https://github.com/)

---

## 📄 License

This project is licensed under the MIT License.
