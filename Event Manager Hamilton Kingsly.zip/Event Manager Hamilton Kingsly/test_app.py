
import pytest
import json
from app import app

@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client

def test_home(client):
    res = client.get("/")
    assert res.status_code == 200
    assert b"Welcome to Event Scheduler System!" in res.data

def test_create_event(client):
    event_data = {
        "title": "Pytest Event",
        "description": "Created by pytest",
        "start_time": "2025-06-28T12:00:00",
        "end_time": "2025-06-28T13:00:00"
    }
    res = client.post("/events", json=event_data)
    assert res.status_code == 201
    response_data = res.get_json()
    assert response_data["event"]["title"] == "Pytest Event"
    return response_data["event"]["id"]

def test_get_events(client):
    res = client.get("/events")
    assert res.status_code == 200
    assert isinstance(res.get_json(), list)

def test_update_event(client):
    # Create event first
    event_id = test_create_event(client)
    updated_data = {
        "title": "Updated Pytest Event"
    }
    res = client.put(f"/events/{event_id}", json=updated_data)
    assert res.status_code == 200
    assert res.get_json()["event"]["title"] == "Updated Pytest Event"

def test_delete_event(client):
    # Create event first
    event_id = test_create_event(client)
    res = client.delete(f"/events/{event_id}")
    assert res.status_code == 200
    assert res.get_json()["message"] == "Event deleted"
