import json
from datetime import datetime

def load_events(filename):
    try:
        with open(filename, "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def save_events(filename, events):
    with open(filename, "w") as f:
        json.dump(events, f, indent=4)

def sort_events(events):
    try:
        return sorted(events, key=lambda x: datetime.fromisoformat(x["start_time"]))
    except Exception:
        return events
